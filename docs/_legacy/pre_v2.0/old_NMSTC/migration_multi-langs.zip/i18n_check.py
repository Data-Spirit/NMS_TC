#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
i18n_check.py : contrôle des blocs de langue d'un guide HTML multilingue (lecture seule).

Vérifie, sans valeur écrite en dur :
  - chaque bloc <script type="application/json" id="i18n-XX"> est un JSON valide avec un "_meta" complet ;
  - toutes les clés utilisées par le HTML (data-i18n, data-i18n-attr) et par le JS (T('…'), TA('…'),
    clés dynamiques cat.<id>, flag.<x>, path.<x>) existent dans la langue source ;
  - chaque langue a EXACTEMENT les clés de la langue source (manquantes = avertissement, ou échec avec --strict ;
    en trop = échec) ;
  - mêmes {paramètres} que la source pour chaque clé ;
  - mêmes balises et mêmes extraits <code> que la source (une traduction ne peut pas altérer les exemples de syntaxe) ;
  - uniquement des balises autorisées, aucun attribut dangereux (on*, javascript:), aucun </script> ;
  - les clés de la langue source jamais utilisées sont signalées.

Usage : python3 i18n_check.py fichier.html [--source fr] [--strict]
Code de sortie : 0 si aucun FAIL, 1 sinon.
"""
import argparse, io, json, re, sys
from collections import Counter

ALLOWED = {'a', 'b', 'br', 'code', 'em', 'i', 'span', 'strong'}
# un bloc de langue commence toujours par « { » : cela écarte les simples mentions dans des commentaires de code
BLOCK_RE = re.compile(r'<script type="application/json" id="i18n-([\w-]+)">(\s*\{.*?)</script>', re.S)
META_REQUIRED = ('native_name', 'flag', 'lang_code')


def read(p):
    with io.open(p, encoding='utf-8', newline='') as f:
        return f.read()


def val(v):
    return ''.join(v) if isinstance(v, list) else v


def skeleton(h):
    return re.findall(r'<[^>]+>', h) + re.findall(r'<code>(.*?)</code>', h, re.S)


def used_keys(html, blocks_text):
    keys = set(re.findall(r'data-i18n="([^"]+)"', html))
    for pair in re.findall(r'data-i18n-attr="([^"]+)"', html):
        keys |= {p.split(':', 1)[1] for p in pair.split(';') if ':' in p}
    script = max(re.findall(r'<script>(.*?)</script>', html, re.S), key=len)
    keys |= {k for k in re.findall(r"\b(?:T|TA|i18nHas)\('([^']+)'", script) if not k.endswith('.')}   # « cat. » = préfixe dynamique
    keys |= {k for k in blocks_text if "'%s'" % k in script}       # clé référencée via une variable
    # clés dynamiques, déduites des données
    cats = set(re.findall(r'^\s*\["[^"]+","[^"]*",(?:\d+(?:\.\d+)?,)?"([a-z0-9_]+)"', script, re.M))
    cats |= set(re.findall(r'^\s*\["[A-Z0-9_]+","[^"]*","([a-z0-9_]+)","', script, re.M))
    for c in cats: keys.add('cat.' + c)
    flags = set(re.findall(r'","(dup|warn|unk)"\],?\s*$', script, re.M))
    for f in flags: keys.add('flag.' + f)
    for p in set(re.findall(r'"@([a-z_]+)"', script)): keys.add('path.' + p)
    if "'cat.' + cat + '.desc'" in script:
        keys |= {k for k in blocks_text if re.fullmatch(r'cat\.[a-z0-9_]+\.desc', k)}
    return keys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('file'); ap.add_argument('--source', default='fr'); ap.add_argument('--strict', action='store_true')
    a = ap.parse_args()
    html = read(a.file)
    res = []
    def R(status, msg, detail=''): res.append((status, msg, detail))

    raw = BLOCK_RE.findall(html)
    ids = [i for i, _ in raw]
    R('PASS' if len(ids) == len(set(ids)) and ids else 'FAIL', 'blocs de langue : %s' % (', '.join(ids) or 'aucun'))
    langs = {}
    for lid, txt in raw:
        try:
            d = json.loads(txt); langs[lid] = d
        except ValueError as e:
            R('FAIL', '%s : JSON invalide' % lid, str(e)[:120])
    if a.source not in langs:
        R('FAIL', 'langue source « %s » absente ou illisible' % a.source)
    else:
        src = {k: val(v) for k, v in langs[a.source].items() if k != '_meta'}
        for lid, d in langs.items():
            meta = d.get('_meta', {})
            miss = [f for f in META_REQUIRED if f not in meta]
            R('PASS' if not miss and meta.get('lang_code') == lid else 'FAIL', '%s : _meta complet (nom, drapeau, code)' % lid,
              ('champs manquants : %s' % miss) if miss else ('lang_code « %s » ≠ id' % meta.get('lang_code') if meta.get('lang_code') != lid else ''))
        mt = re.search(r'<title>(.*?)</title>', html, re.S)
        import html as _h
        R('PASS' if mt and _h.unescape(mt.group(1)).strip() == src.get('page.title', '').strip() else 'FAIL',
          '<title> statique identique à la clé page.title de la source (valeur de secours sans JavaScript)',
          '' if mt else '<title> absent')
        used = used_keys(html, src)
        absent = sorted(k for k in used if k not in src)
        R('PASS' if not absent else 'FAIL', 'clés utilisées par le HTML et le JS présentes dans la source (%d clés)' % len(used), ', '.join(absent[:6]))
        unused = sorted(k for k in src if k not in used)
        R('PASS' if not unused else 'WARN', 'clés de la source jamais utilisées', ', '.join(unused[:6]))
        for lid, d in langs.items():
            tr = {k: val(v) for k, v in d.items() if k != '_meta'}
            miss = sorted(set(src) - set(tr)); extra = sorted(set(tr) - set(src))
            if lid != a.source:
                R('PASS' if not miss else ('FAIL' if a.strict else 'WARN'), '%s : clés manquantes (repli sur %s à l\'affichage) : %d / %d' % (lid, a.source, len(miss), len(src)), ', '.join(miss[:6]))
                R('PASS' if not extra else 'FAIL', '%s : clés en trop (absentes de la source)' % lid, ', '.join(extra[:6]))
            bad_ph = [k for k in tr if k in src and Counter(re.findall(r'\{(\w+)\}', tr[k])) != Counter(re.findall(r'\{(\w+)\}', src[k]))]
            R('PASS' if not bad_ph else 'FAIL', '%s : mêmes {paramètres} que la source' % lid, ', '.join(bad_ph[:6]))
            bad_sk = [k for k in tr if k in src and skeleton(tr[k]) != skeleton(src[k])]
            R('PASS' if not bad_sk else 'FAIL', '%s : mêmes balises et mêmes extraits <code> que la source' % lid, ', '.join(bad_sk[:6]))
            forbidden, dangerous = [], []
            for k, v in tr.items():
                for t in re.findall(r'<\s*/?\s*([a-zA-Z][\w-]*)', v):
                    if t.lower() not in ALLOWED: forbidden.append('%s:<%s>' % (k, t))
                if re.search(r'\son\w+\s*=|javascript:', v, re.I): dangerous.append(k)
            R('PASS' if not forbidden else 'FAIL', '%s : uniquement des balises autorisées' % lid, ', '.join(forbidden[:6]))
            R('PASS' if not dangerous else 'FAIL', '%s : aucun attribut dangereux (on…=, javascript:)' % lid, ', '.join(dangerous[:6]))
    for dest in [r for r in raw if '</script' in r[1].lower()]:
        R('FAIL', '%s : séquence </script interdite dans un bloc' % dest[0])
    order = {'FAIL': 0, 'WARN': 1, 'PASS': 2}
    for s, m, d in res: print('%s %s%s' % (s, m, (' : ' + d) if d else ''))
    c = Counter(s for s, _, _ in res)
    print('\nRésumé : %d PASS, %d FAIL, %d WARN' % (c['PASS'], c['FAIL'], c['WARN']))
    sys.exit(0 if c['FAIL'] == 0 else 1)


if __name__ == '__main__':
    main()
