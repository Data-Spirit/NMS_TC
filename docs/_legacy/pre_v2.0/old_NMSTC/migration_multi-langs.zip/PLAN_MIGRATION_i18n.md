# Plan de migration : un seul HTML multilingue (prototype validé)

Date : 2026-10-19. Statut : **prototype fonctionnel livré, rien d'adopté**. Aucun fichier existant du dépôt n'a été modifié.

## 1. Résumé

| Question | Réponse |
|---|---|
| Faisable en un seul fichier HTML autonome ? | **Oui, prouvé par un prototype** (FR + EN). |
| Le rendu change-t-il ? | **Non** : le prototype affiche exactement la même page que le guide FR v1.3 en français et que l'EN v1.3 en anglais, y compris après 14 scénarios d'interaction. |
| Les textes anglais ont-ils été retraduits ? | **Non** : ils sont extraits automatiquement de l'EN v1.3 (structure identique au FR). |
| Poids | Prototype à 2 langues : **352 448 octets** (FR v1.3 : 326 605). Chaque langue ajoute environ **13 Kio**. |
| Ce qui reste à faire pour adopter | Valider les décisions du §6, puis relecture visuelle par toi (je ne peux pas juger l'affichage). |

## 2. Architecture retenue

```
[ tout le guide comme aujourd'hui : CSS, HTML, JavaScript, ICON_DATA ]
<!-- ===== LANGUE : FRANÇAIS (source / par défaut) ===== -->
<script type="application/json" id="i18n-fr"> { "_meta": {...}, "clé": "texte", ... } </script>
<!-- ===== LANGUE : ENGLISH ===== -->
<script type="application/json" id="i18n-en"> { "_meta": {...}, "clé": "texte", ... } </script>
</body>
```

- **Un bloc JSON par langue**, indépendant. Un bloc illisible est ignoré : les autres langues continuent de fonctionner (testé).
- **`_meta`** en tête de chaque bloc : nom dans sa langue, drapeau, code, version de la traduction, date, et les **paramètres de traduction** (variante, ton, fidélité, style des `aria-label`). Le sélecteur de langue se construit tout seul à partir de `_meta`.
- **Le HTML ne contient plus de texte traduisible** : chaque élément porte une clé (`data-i18n="infos.li.03"`), et les attributs (`placeholder`, `aria-label`, `title`) passent par `data-i18n-attr`. Seul le `<title>` garde sa valeur française en dur, comme valeur de secours pour les aperçus de lien qui n'exécutent pas le JavaScript.
- **Mise en forme libre** : les textes peuvent contenir `strong`, `em`, `b`, `i`, `code`, `span class="…"`, `br` et `a` (liste blanche). Tout le reste (script, iframe, `onclick`, `javascript:`) est neutralisé à l'affichage. Ajouter une balise à la liste = une ligne dans `I18N_ALLOWED`.
- **Textes longs** : une valeur peut être une chaîne ou une liste de morceaux recollés au chargement, pour garder des paragraphes lisibles sur plusieurs lignes.
- **Repli** : clé absente dans une langue → texte de la langue par défaut (`DEFAULT_LANG = 'fr'`), et la clé est listée dans `I18N.missing`.
- **Choix de la langue** : langue mémorisée (`localStorage`, protégé par `try/catch`), sinon langue du navigateur si elle existe, sinon français. Sélecteur `<select>` natif en haut à droite du bandeau : « 🇫🇷 Français », « 🇬🇧 English ».
- **Initialisation** à la fin du chargement de la page (`DOMContentLoaded`), car les blocs de langues sont après le script principal.

## 3. Ce qui a changé dans le code

- **13 fonctions ajoutées** : moteur (`i18nLoad`, `i18nSanitize`, `i18nRaw`, `i18nHas`, `i18nHtml`, `i18nFill`, `T`, `TA`) et orchestration (`fillCatFilter`, `detectLanguage`, `buildLangSelector`, `applyLanguage`, `initPage`). **1 remplacée** : `populateCatFilter` devient `fillCatFilter` (sans réinscrire l'écouteur à chaque appel). Aucune autre fonction supprimée.
- **Données** : les 21 catégories ne sont plus des mots français répétés 204 fois, mais des **identifiants neutres** (`resources`, `loot`, `class_c_s`…) avec leurs libellés dans les langues (`cat.resources`). Les 3 libellés de « chemin » (« (chemin non listé) »…) deviennent des jetons (`@unlisted`, `@portal`, `@none`). Tous les champs techniques de `COLORS` (59 lignes) et `ICONS` (145 lignes) sont **identiques** à la v1.3.
- **Blocs strictement identiques à la v1.3** : `ICON_DATA`, `CONTAINER_EXAMPLES`, `ICON_ALREADY_COLORED`, `SPECTRUM_ORDER`.
- **Blocs déplacés dans les langues** : `CATEGORY_DESCRIPTIONS` et `FLAG_LABELS`.
- **Messages du simulateur** (balise inconnue, erreur de casse…) : lus dans les langues avec des `{paramètres}`.
- **CSS** : 4 règles (sélecteur de langue et son état de focus, `position:relative` sur le bandeau).

## 4. Inventaire : 116 clés

| Zone | Clés | Contenu |
|---|---|---|
| `hero` | 11 | bandeau, simulateur, aides, boutons copier/effacer |
| `nav` | 4 | onglets |
| `infos` | 24 | onglet Infos (encadrés, listes, exemples) |
| `colors` | 10 | onglet Couleurs (en-têtes de tri, recherche) |
| `icons` | 8 | onglet Icônes |
| `about` | 20 | onglet À propos |
| `footer` | 1 | pied de page |
| `page`, `lang` | 2 | titre de page, libellé du sélecteur |
| `copy`, `count`, `icon`, `sim`, `flag`, `path` | 14 | textes générés par le JavaScript |
| `cat` | 22 | 21 libellés de catégories + 1 description |

Nommage actuel : `zone.élément.NN` (ex. `infos.li.03`). Il est généré automatiquement et se renomme sans risque (la suite de tests le détecterait).

## 5. Preuves exécutées

| Contrôle | Résultat |
|---|---|
| Rendu du prototype en FR identique au guide FR v1.3 | **18 / 18** (état initial, simulateur, recherches, tris, filtre, onglets, bascule de langue et retour) |
| Rendu du prototype en EN identique à l'EN v1.3 | **18 / 18** |
| Test de comportement existant (copie, croix, erreurs de balise, exemples, onglets, icônes non fonctionnelles, non-régression du rendu) | **35 / 35** en FR et **35 / 35** en EN |
| Robustesse : traduction malveillante neutralisée, bloc illisible isolé, langue partielle avec repli, détection du navigateur, `localStorage` bloqué | **22 / 22** |
| Contrôle des clés (clés, `{paramètres}`, balises, extraits `<code>`, balises interdites, `_meta`, `<title>`) | **16 / 16** sur le prototype ; **8 variantes défectueuses** toutes détectées pour la bonne raison |
| Construction reproductible depuis le dossier `tools/` | md5 identique au prototype : `2e24490e7aa065f8bf69721647dd5cf9` |
| `node --check`, html-validate | OK (html-validate avec 2 règles désactivées : `empty-heading` et `text-content`, qui signalent des éléments « vides jusqu'au remplissage par le JavaScript ») |

**Défaut trouvé pendant ces tests (dans mon test n° 3 déjà livré)** : il ne contrôlait pas réellement le cas des 16 icônes « non fonctionnelles » (`ICON_MAP` les contient avec une valeur vide, donc le test les croyait fonctionnelles et sautait la vérification sans le dire). Le comportement du guide était correct (« ? » sans erreur). La version corrigée est dans `tools/test_behavior_lang.js`.

## 6. Ce que je n'ai pas pu vérifier

- **Le rendu visuel** : position du sélecteur en haut à droite (surtout sur mobile), débordements avec des textes plus longs, aspect des drapeaux. Les tests tournent dans une simulation de navigateur (jsdom), pas dans Chrome, Firefox ou Safari.
- **Les drapeaux emoji sous Windows**, qui s'affichent souvent en deux lettres. Ton repli (image SVG ou PNG) reste possible.
- **Les langues non latines** (polices, longueur) : aucune n'est encore dans le fichier.
- **Les pluriels** : les seuls textes avec compteur sont « {n} / {total} balises » et « transparence {pct}% », sans accord grammatical problématique à ma connaissance, mais à surveiller pour le russe ou le polonais.
- **Polices** : le guide charge Rajdhani, IBM Plex Sans et JetBrains Mono depuis Google Fonts (déjà le cas avant). Hors ligne, il retombe sur des polices système. Ce n'est pas lié à la migration.

## 7. Décisions à valider avant adoption

1. **Numéro de version** : le prototype porte `2.0 (prototype multilingue)`, car la structure interne change. À confirmer.
2. **Langue par défaut** : français (comme demandé). Un visiteur dont la langue n'existe pas voit le français ; option : anglais, plus universel.
3. **Texte absent du HTML** : choix volontaire (une seule source de vérité : le bloc français). Contrepartie : éléments vides avant le chargement du JavaScript et deux règles html-validate désactivées.
4. **Sélecteur** natif `<select>` (simple, accessible) ou menu personnalisé plus joli mais plus lourd.
5. **Espagnol** : comme il n'a jamais été livré à jour, c'est simplement un nouveau bloc de 116 clés (≈ 13 Kio) à traduire, avec le FR et l'EN comme références.
6. **Outils de migration** (`i18n_build.py`, `i18n_extract.py`, moteurs JS) : ne vont pas dans le dépôt ; utiles seulement si le FR évolue avant l'adoption (on relance la construction).

## 8. Nouveau fonctionnement une fois adopté

**Ajouter une fonctionnalité** : écrire le HTML avec ses clés, ajouter les clés dans le bloc FR, lancer le contrôle des clés (il liste ce qui manque ailleurs), puis traduire **uniquement ces clés** dans les autres blocs.

**Ajouter une langue** : copier le bloc FR, remplir `_meta` (nom, drapeau, paramètres de traduction), traduire les valeurs. Le sélecteur la propose automatiquement ; rien d'autre à toucher.

**Contrôler** : `python3 i18n_check.py guide.html --strict` (clés manquantes ou en trop, paramètres, extraits de code, balises interdites) ; `test_equiv.js` (rendu identique à une référence) ; `test_behavior_lang.js` (comportement dans chaque langue) ; `test_runtime.js` (robustesse).

## 9. Impact sur le dépôt (proposition, après ta validation)

| Élément | Sort proposé |
|---|---|
| `trans_script_1_substitutions_*.json`, `trans_script_2_update_translation.py` | À supprimer (ne servent qu'aux fichiers séparés) |
| `trans_script_4_verify_symmetry.py` | À supprimer (remplacé par `i18n_check.py`) |
| `trans_script_3_test_behavior.js` | Remplacé par `test_behavior_lang.js` (corrigé, multilingue) |
| `trans_script_0_README.md` | À réécrire pour les nouveaux outils |
| `NMS_txt_code_EN.html` et fichiers de langue séparés | Retirés une fois le fichier unique publié |
| `prompt_translation_HTML_GUIDE_LANG.md` | À refondre (traduire des clés, lire les paramètres dans `_meta`, nouveau contrôle) |
| README par langue (`README_FR.md`, `README_EN.md`) | Conservés (GitHub ne peut pas les faire changer de langue) ; leur prompt reste valable |

## 10. Étapes proposées

1. Tu relis le prototype dans ton navigateur (affichage, sélecteur, drapeaux, bascule FR/EN).
2. Tu valides ou corriges les décisions du §7.
3. Je présente le texte exact de la refonte du prompt HTML et la liste des fichiers à supprimer.
4. Publication du fichier unique, puis ajout de l'espagnol.
