const fs = require('fs'); const { JSDOM, VirtualConsole } = require('jsdom');
const SRC = fs.readFileSync(process.argv[2], 'utf8');
let fails = 0; const ok = (c, m, d='') => { console.log((c ? 'PASS ' : 'FAIL ') + m + (c || !d ? '' : ' : ' + d)); if(!c) fails++; };
const tick = (ms = 40) => new Promise(r => setTimeout(r, ms));
async function open(html, { languages, storage } = {}){
  const errors = [], vc = new VirtualConsole(); vc.on('jsdomError', e => errors.push(String(e.message).slice(0, 80))); vc.on('error', (...a) => errors.push(a.join(' ').slice(0, 100)));
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true, url: 'http://localhost/', virtualConsole: vc,
    beforeParse(w){
      if(languages) Object.defineProperty(w.navigator, 'languages', { value: languages, configurable: true });
      if(storage === 'blocked') Object.defineProperty(w, 'localStorage', { get(){ throw new Error('SecurityError'); }, configurable: true });
    } });
  await new Promise(r => { if(dom.window.document.readyState === 'complete') r(); else dom.window.addEventListener('load', r); }); await tick();
  dom.window.__errors = errors; return dom.window;
}
const inBlock = (html, id, fn) => { const i = html.indexOf('id="i18n-' + id + '"'); const j = html.indexOf('</script>', i); return html.slice(0, i) + fn(html.slice(i, j)) + html.slice(j); };

(async () => {
  console.log('--- A. sécurité : une traduction malveillante est neutralisée');
  const evil = inBlock(SRC, 'en', b => b.replace('"nav.tab.infos": "Info"', '"nav.tab.infos": "Info<img src=x onerror=\\"window.__pwn=1\\"><a href=\\"javascript:alert(1)\\" onclick=\\"window.__pwn2=1\\" class=\\"ok\\">x</a><iframe src=\\"//evil\\"></iframe><svg onload=\\"window.__pwn3=1\\"></svg><b onmouseover=\\"window.__pwn4=1\\">b</b>"'));
  let w = await open(evil, { languages: ['en'] });
  const btn = w.document.querySelector('.tab-btn[data-tab="infos"]');
  ok(btn.querySelector('img,iframe,svg,script') === null, 'aucune balise dangereuse (img, iframe, svg, script) dans le bouton', btn.innerHTML);
  ok(btn.querySelector('a') && !btn.querySelector('a').hasAttribute('href') && !btn.querySelector('a').hasAttribute('onclick'), 'lien : href javascript: et onclick supprimés', btn.innerHTML);
  ok(btn.querySelector('a').className === 'ok', 'attribut class autorisé conservé');
  ok(!btn.querySelector('b').hasAttribute('onmouseover'), 'gestionnaire onmouseover supprimé');
  ok(!w.__pwn && !w.__pwn2 && !w.__pwn3 && !w.__pwn4, 'aucun code de la traduction ne s\'est exécuté');
  ok(btn.textContent.startsWith('Info'), 'le texte légitime est conservé : « ' + btn.textContent.slice(0, 30) + ' »');

  console.log('\n--- B. un bloc de langue illisible n\'affecte pas les autres');
  const broken = inBlock(SRC, 'en', b => b.replace('"lang.label": "Language",', '"lang.label": "Language" "oops",'));
  w = await open(broken, { languages: ['en'] });
  ok(w.eval('I18N.order.join(",")') === 'fr', 'seul le français est chargé', w.eval('I18N.order.join(",")'));
  ok(w.document.getElementById('lang-select').options.length === 1, 'le sélecteur ne propose que le français');
  ok(w.document.querySelector('.tab-btn[data-tab="infos"]').textContent.trim() === 'Infos' && w.document.documentElement.lang === 'fr', 'la page fonctionne en français malgré l\'erreur');
  ok(w.document.querySelectorAll('#color-table-wrap .color-row-wrap').length === 59 && w.document.querySelectorAll('#icon-table-wrap tbody tr').length === 145, 'tableaux de 59 couleurs et 145 icônes rendus');

  console.log('\n--- C. langue partielle : repli sur le français, signalé');
  const partial = SRC.replace('</body>', '<script type="application/json" id="i18n-xx">{"_meta":{"native_name":"Testish","flag":"🏳️","lang_code":"xx"},"nav.tab.infos":"INFO-XX","hero.eyebrow":"EYEBROW-XX"}</script>\n</body>');
  w = await open(partial, { languages: ['en'] });
  w.eval("applyLanguage('xx')"); await tick();
  ok(w.document.querySelector('.tab-btn[data-tab="infos"]').textContent.trim() === 'INFO-XX', 'clé présente : traduite');
  ok(w.document.querySelector('.tab-btn[data-tab="colors"]').textContent.trim() === 'Couleurs', 'clé absente : repli sur le français');
  ok(w.eval('Array.from(I18N.missing).filter(k => k.startsWith("xx:")).length') > 100, 'clés manquantes listées dans I18N.missing', String(w.eval('I18N.missing.size')));
  ok(w.eval('I18N.order.join(",")') === 'fr,en,xx' && w.document.getElementById('lang-select').options.length === 3, 'le sélecteur propose automatiquement la nouvelle langue');
  ok(w.document.querySelector('#lang-select option[value="xx"]').textContent.includes('Testish'), 'libellé du sélecteur lu dans _meta');

  console.log('\n--- D. détection de la langue du navigateur');
  for(const [langs, expect, label] of [[['en-GB', 'fr'], 'en', 'en-GB → en'], [['de', 'fr-CA'], 'fr', 'de puis fr-CA → fr'], [['de'], 'fr', 'de (inconnue) → langue par défaut fr'], [['fr-FR'], 'fr', 'fr-FR → fr']]){
    w = await open(SRC, { languages: langs });
    ok(w.document.documentElement.lang === expect && w.document.getElementById('lang-select').value === expect, label, w.document.documentElement.lang);
  }
  w = await open(SRC, { languages: ['en'] });
  w.document.getElementById('lang-select').value = 'fr'; w.document.getElementById('lang-select').dispatchEvent(new w.Event('change')); await tick();
  ok(w.document.documentElement.lang === 'fr' && w.localStorage.getItem('nmstc-lang') === 'fr', 'le changement via le sélecteur est appliqué et mémorisé');

  console.log('\n--- E. stockage bloqué par le navigateur');
  w = await open(SRC, { languages: ['en'], storage: 'blocked' });
  ok(w.document.documentElement.lang === 'en' && w.document.querySelectorAll('#color-table-wrap .color-row-wrap').length === 59, 'la page fonctionne sans localStorage');
  w.document.getElementById('lang-select').value = 'fr'; w.document.getElementById('lang-select').dispatchEvent(new w.Event('change')); await tick();
  ok(w.document.documentElement.lang === 'fr', 'le changement de langue fonctionne aussi sans localStorage');
  console.log(fails ? `\n${fails} ÉCHEC(S)` : '\nTOUT OK'); process.exit(fails ? 1 : 0);
})();
